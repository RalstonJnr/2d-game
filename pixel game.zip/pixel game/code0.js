gdjs.OverworldCode = {};
gdjs.OverworldCode.localVariables = [];
gdjs.OverworldCode.GDDialogBoxObjects1= [];
gdjs.OverworldCode.GDDialogBoxObjects2= [];
gdjs.OverworldCode.GDDialogBoxObjects3= [];
gdjs.OverworldCode.GDDialogBoxObjects4= [];
gdjs.OverworldCode.GDPlayerObjects1= [];
gdjs.OverworldCode.GDPlayerObjects2= [];
gdjs.OverworldCode.GDPlayerObjects3= [];
gdjs.OverworldCode.GDPlayerObjects4= [];
gdjs.OverworldCode.GDTree1Objects1= [];
gdjs.OverworldCode.GDTree1Objects2= [];
gdjs.OverworldCode.GDTree1Objects3= [];
gdjs.OverworldCode.GDTree1Objects4= [];
gdjs.OverworldCode.GDTree2Objects1= [];
gdjs.OverworldCode.GDTree2Objects2= [];
gdjs.OverworldCode.GDTree2Objects3= [];
gdjs.OverworldCode.GDTree2Objects4= [];
gdjs.OverworldCode.GDBush1Objects1= [];
gdjs.OverworldCode.GDBush1Objects2= [];
gdjs.OverworldCode.GDBush1Objects3= [];
gdjs.OverworldCode.GDBush1Objects4= [];
gdjs.OverworldCode.GDHouse1Objects1= [];
gdjs.OverworldCode.GDHouse1Objects2= [];
gdjs.OverworldCode.GDHouse1Objects3= [];
gdjs.OverworldCode.GDHouse1Objects4= [];
gdjs.OverworldCode.GDHouse2Objects1= [];
gdjs.OverworldCode.GDHouse2Objects2= [];
gdjs.OverworldCode.GDHouse2Objects3= [];
gdjs.OverworldCode.GDHouse2Objects4= [];
gdjs.OverworldCode.GDEObjects1= [];
gdjs.OverworldCode.GDEObjects2= [];
gdjs.OverworldCode.GDEObjects3= [];
gdjs.OverworldCode.GDEObjects4= [];
gdjs.OverworldCode.GDE2Objects1= [];
gdjs.OverworldCode.GDE2Objects2= [];
gdjs.OverworldCode.GDE2Objects3= [];
gdjs.OverworldCode.GDE2Objects4= [];
gdjs.OverworldCode.GDShadedDarkJoystickObjects1= [];
gdjs.OverworldCode.GDShadedDarkJoystickObjects2= [];
gdjs.OverworldCode.GDShadedDarkJoystickObjects3= [];
gdjs.OverworldCode.GDShadedDarkJoystickObjects4= [];
gdjs.OverworldCode.GDTargetRoundButtonObjects1= [];
gdjs.OverworldCode.GDTargetRoundButtonObjects2= [];
gdjs.OverworldCode.GDTargetRoundButtonObjects3= [];
gdjs.OverworldCode.GDTargetRoundButtonObjects4= [];
gdjs.OverworldCode.GDTilemap_9595GroundObjects1= [];
gdjs.OverworldCode.GDTilemap_9595GroundObjects2= [];
gdjs.OverworldCode.GDTilemap_9595GroundObjects3= [];
gdjs.OverworldCode.GDTilemap_9595GroundObjects4= [];
gdjs.OverworldCode.GDTilemap_9595WaterObjects1= [];
gdjs.OverworldCode.GDTilemap_9595WaterObjects2= [];
gdjs.OverworldCode.GDTilemap_9595WaterObjects3= [];
gdjs.OverworldCode.GDTilemap_9595WaterObjects4= [];
gdjs.OverworldCode.GDcoinObjects1= [];
gdjs.OverworldCode.GDcoinObjects2= [];
gdjs.OverworldCode.GDcoinObjects3= [];
gdjs.OverworldCode.GDcoinObjects4= [];
gdjs.OverworldCode.GDscrollObjects1= [];
gdjs.OverworldCode.GDscrollObjects2= [];
gdjs.OverworldCode.GDscrollObjects3= [];
gdjs.OverworldCode.GDscrollObjects4= [];
gdjs.OverworldCode.GDchest1Objects1= [];
gdjs.OverworldCode.GDchest1Objects2= [];
gdjs.OverworldCode.GDchest1Objects3= [];
gdjs.OverworldCode.GDchest1Objects4= [];
gdjs.OverworldCode.GDchest2Objects1= [];
gdjs.OverworldCode.GDchest2Objects2= [];
gdjs.OverworldCode.GDchest2Objects3= [];
gdjs.OverworldCode.GDchest2Objects4= [];
gdjs.OverworldCode.GDchest3Objects1= [];
gdjs.OverworldCode.GDchest3Objects2= [];
gdjs.OverworldCode.GDchest3Objects3= [];
gdjs.OverworldCode.GDchest3Objects4= [];
gdjs.OverworldCode.GDCoinTallyObjects1= [];
gdjs.OverworldCode.GDCoinTallyObjects2= [];
gdjs.OverworldCode.GDCoinTallyObjects3= [];
gdjs.OverworldCode.GDCoinTallyObjects4= [];
gdjs.OverworldCode.GDWelcomeObjects1= [];
gdjs.OverworldCode.GDWelcomeObjects2= [];
gdjs.OverworldCode.GDWelcomeObjects3= [];
gdjs.OverworldCode.GDWelcomeObjects4= [];
gdjs.OverworldCode.GDPopupBox1Objects1= [];
gdjs.OverworldCode.GDPopupBox1Objects2= [];
gdjs.OverworldCode.GDPopupBox1Objects3= [];
gdjs.OverworldCode.GDPopupBox1Objects4= [];
gdjs.OverworldCode.GDCongratsMessageObjects1= [];
gdjs.OverworldCode.GDCongratsMessageObjects2= [];
gdjs.OverworldCode.GDCongratsMessageObjects3= [];
gdjs.OverworldCode.GDCongratsMessageObjects4= [];
gdjs.OverworldCode.GDbackButtonObjects1= [];
gdjs.OverworldCode.GDbackButtonObjects2= [];
gdjs.OverworldCode.GDbackButtonObjects3= [];
gdjs.OverworldCode.GDbackButtonObjects4= [];
gdjs.OverworldCode.GDgitHub1Objects1= [];
gdjs.OverworldCode.GDgitHub1Objects2= [];
gdjs.OverworldCode.GDgitHub1Objects3= [];
gdjs.OverworldCode.GDgitHub1Objects4= [];
gdjs.OverworldCode.GDproject1Objects1= [];
gdjs.OverworldCode.GDproject1Objects2= [];
gdjs.OverworldCode.GDproject1Objects3= [];
gdjs.OverworldCode.GDproject1Objects4= [];
gdjs.OverworldCode.GDChestTallyObjects1= [];
gdjs.OverworldCode.GDChestTallyObjects2= [];
gdjs.OverworldCode.GDChestTallyObjects3= [];
gdjs.OverworldCode.GDChestTallyObjects4= [];
gdjs.OverworldCode.GDBoatObjects1= [];
gdjs.OverworldCode.GDBoatObjects2= [];
gdjs.OverworldCode.GDBoatObjects3= [];
gdjs.OverworldCode.GDBoatObjects4= [];
gdjs.OverworldCode.GDTurtleObjects1= [];
gdjs.OverworldCode.GDTurtleObjects2= [];
gdjs.OverworldCode.GDTurtleObjects3= [];
gdjs.OverworldCode.GDTurtleObjects4= [];
gdjs.OverworldCode.GDproject2Objects1= [];
gdjs.OverworldCode.GDproject2Objects2= [];
gdjs.OverworldCode.GDproject2Objects3= [];
gdjs.OverworldCode.GDproject2Objects4= [];
gdjs.OverworldCode.GDgitHub2Objects1= [];
gdjs.OverworldCode.GDgitHub2Objects2= [];
gdjs.OverworldCode.GDgitHub2Objects3= [];
gdjs.OverworldCode.GDgitHub2Objects4= [];
gdjs.OverworldCode.GDPopupBox2Objects1= [];
gdjs.OverworldCode.GDPopupBox2Objects2= [];
gdjs.OverworldCode.GDPopupBox2Objects3= [];
gdjs.OverworldCode.GDPopupBox2Objects4= [];
gdjs.OverworldCode.GDbackButton2Objects1= [];
gdjs.OverworldCode.GDbackButton2Objects2= [];
gdjs.OverworldCode.GDbackButton2Objects3= [];
gdjs.OverworldCode.GDbackButton2Objects4= [];
gdjs.OverworldCode.GDCongratsMessage2Objects1= [];
gdjs.OverworldCode.GDCongratsMessage2Objects2= [];
gdjs.OverworldCode.GDCongratsMessage2Objects3= [];
gdjs.OverworldCode.GDCongratsMessage2Objects4= [];
gdjs.OverworldCode.GDCongratsMessage3Objects1= [];
gdjs.OverworldCode.GDCongratsMessage3Objects2= [];
gdjs.OverworldCode.GDCongratsMessage3Objects3= [];
gdjs.OverworldCode.GDCongratsMessage3Objects4= [];
gdjs.OverworldCode.GDPopupBox3Objects1= [];
gdjs.OverworldCode.GDPopupBox3Objects2= [];
gdjs.OverworldCode.GDPopupBox3Objects3= [];
gdjs.OverworldCode.GDPopupBox3Objects4= [];
gdjs.OverworldCode.GDbackButton3Objects1= [];
gdjs.OverworldCode.GDbackButton3Objects2= [];
gdjs.OverworldCode.GDbackButton3Objects3= [];
gdjs.OverworldCode.GDbackButton3Objects4= [];
gdjs.OverworldCode.GDInfo2Objects1= [];
gdjs.OverworldCode.GDInfo2Objects2= [];
gdjs.OverworldCode.GDInfo2Objects3= [];
gdjs.OverworldCode.GDInfo2Objects4= [];
gdjs.OverworldCode.GDinfoTextObjects1= [];
gdjs.OverworldCode.GDinfoTextObjects2= [];
gdjs.OverworldCode.GDinfoTextObjects3= [];
gdjs.OverworldCode.GDinfoTextObjects4= [];
gdjs.OverworldCode.GDInfoBox_9595Objects1= [];
gdjs.OverworldCode.GDInfoBox_9595Objects2= [];
gdjs.OverworldCode.GDInfoBox_9595Objects3= [];
gdjs.OverworldCode.GDInfoBox_9595Objects4= [];
gdjs.OverworldCode.GDButtonObjects1= [];
gdjs.OverworldCode.GDButtonObjects2= [];
gdjs.OverworldCode.GDButtonObjects3= [];
gdjs.OverworldCode.GDButtonObjects4= [];
gdjs.OverworldCode.GDNewTextInputObjects1= [];
gdjs.OverworldCode.GDNewTextInputObjects2= [];
gdjs.OverworldCode.GDNewTextInputObjects3= [];
gdjs.OverworldCode.GDNewTextInputObjects4= [];
gdjs.OverworldCode.GDQuizzObjects1= [];
gdjs.OverworldCode.GDQuizzObjects2= [];
gdjs.OverworldCode.GDQuizzObjects3= [];
gdjs.OverworldCode.GDQuizzObjects4= [];
gdjs.OverworldCode.GDTransitionObjects1= [];
gdjs.OverworldCode.GDTransitionObjects2= [];
gdjs.OverworldCode.GDTransitionObjects3= [];
gdjs.OverworldCode.GDTransitionObjects4= [];


gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDTree1Objects1ObjectsGDgdjs_9546OverworldCode_9546GDBush1Objects1ObjectsGDgdjs_9546OverworldCode_9546GDTree2Objects1ObjectsGDgdjs_9546OverworldCode_9546GDHouse1Objects1ObjectsGDgdjs_9546OverworldCode_9546GDHouse2Objects1ObjectsGDgdjs_9546OverworldCode_9546GDTilemap_95959595GroundObjects1ObjectsGDgdjs_9546OverworldCode_9546GDTilemap_95959595WaterObjects1Objects = Hashtable.newFrom({"Tree1": gdjs.OverworldCode.GDTree1Objects1, "Bush1": gdjs.OverworldCode.GDBush1Objects1, "Tree2": gdjs.OverworldCode.GDTree2Objects1, "House1": gdjs.OverworldCode.GDHouse1Objects1, "House2": gdjs.OverworldCode.GDHouse2Objects1, "Tilemap_Ground": gdjs.OverworldCode.GDTilemap_9595GroundObjects1, "Tilemap_Water": gdjs.OverworldCode.GDTilemap_9595WaterObjects1});
gdjs.OverworldCode.asyncCallback17178260 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.OverworldCode.localVariables);
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Battle");
}gdjs.OverworldCode.localVariables.length = 0;
}
gdjs.OverworldCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.OverworldCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.25), (runtimeScene) => (gdjs.OverworldCode.asyncCallback17178260(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.OverworldCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.OverworldCode.GDDialogBoxObjects2, gdjs.OverworldCode.GDDialogBoxObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogBoxObjects3.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogBoxObjects3[i].IsYesClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDDialogBoxObjects3[k] = gdjs.OverworldCode.GDDialogBoxObjects3[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogBoxObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.OverworldCode.GDTransitionObjects3);
{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects3.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects3[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Forward", 255, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OverworldCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.OverworldCode.GDDialogBoxObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogBoxObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogBoxObjects2[i].IsNoClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDDialogBoxObjects2[k] = gdjs.OverworldCode.GDDialogBoxObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogBoxObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.OverworldCode.GDDialogBoxObjects2 */
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDDialogBoxObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogBoxObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.OverworldCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "e");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtsExt__SpriteMultitouchJoystick__IsButtonPressed.func(runtimeScene, 1, "A", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17175540);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
/* Unknown object - skipped. */}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DialogBox"), gdjs.OverworldCode.GDDialogBoxObjects2);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDDialogBoxObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogBoxObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects2[i].activateBehavior("TopDownMovement", false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Talk.wav", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DialogBox"), gdjs.OverworldCode.GDDialogBoxObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogBoxObjects2.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogBoxObjects2[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDDialogBoxObjects2[k] = gdjs.OverworldCode.GDDialogBoxObjects2[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogBoxObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.OverworldCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustResumed(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("DialogBox"), gdjs.OverworldCode.GDDialogBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.OverworldCode.GDTransitionObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTransitionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDDialogBoxObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.OverworldCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
/* Reuse gdjs.OverworldCode.GDShadedDarkJoystickObjects2 */
gdjs.copyArray(runtimeScene.getObjects("TargetRoundButton"), gdjs.OverworldCode.GDTargetRoundButtonObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDShadedDarkJoystickObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.OverworldCode.GDTargetRoundButtonObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDTargetRoundButtonObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDDialogBoxObjects1ObjectsGDgdjs_9546OverworldCode_9546GDTargetRoundButtonObjects1Objects = Hashtable.newFrom({"DialogBox": gdjs.OverworldCode.GDDialogBoxObjects1, "TargetRoundButton": gdjs.OverworldCode.GDTargetRoundButtonObjects1});
gdjs.OverworldCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.OverworldCode.GDShadedDarkJoystickObjects2);
{for(var i = 0, len = gdjs.OverworldCode.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDShadedDarkJoystickObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDShadedDarkJoystickObjects2.length ;i < len;++i) {
    gdjs.OverworldCode.GDShadedDarkJoystickObjects2[i].ActivateControl(false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.OverworldCode.eventsList3(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("DialogBox"), gdjs.OverworldCode.GDDialogBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("TargetRoundButton"), gdjs.OverworldCode.GDTargetRoundButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDDialogBoxObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDDialogBoxObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.OverworldCode.GDDialogBoxObjects1[k] = gdjs.OverworldCode.GDDialogBoxObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDDialogBoxObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDTargetRoundButtonObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDTargetRoundButtonObjects1[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.OverworldCode.GDTargetRoundButtonObjects1[k] = gdjs.OverworldCode.GDTargetRoundButtonObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDTargetRoundButtonObjects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDDialogBoxObjects1ObjectsGDgdjs_9546OverworldCode_9546GDTargetRoundButtonObjects1Objects, runtimeScene, false, false);
}
isConditionTrue_0 = !isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ShadedDarkJoystick"), gdjs.OverworldCode.GDShadedDarkJoystickObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDShadedDarkJoystickObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDShadedDarkJoystickObjects1[i].TeleportAndPress((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDcoinObjects1Objects = Hashtable.newFrom({"coin": gdjs.OverworldCode.GDcoinObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDscrollObjects1Objects = Hashtable.newFrom({"scroll": gdjs.OverworldCode.GDscrollObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDchest1Objects1Objects = Hashtable.newFrom({"chest1": gdjs.OverworldCode.GDchest1Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDgitHub1Objects1Objects = Hashtable.newFrom({"gitHub1": gdjs.OverworldCode.GDgitHub1Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDproject1Objects1Objects = Hashtable.newFrom({"project1": gdjs.OverworldCode.GDproject1Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDchest2Objects1Objects = Hashtable.newFrom({"chest2": gdjs.OverworldCode.GDchest2Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDgitHub2Objects1Objects = Hashtable.newFrom({"gitHub2": gdjs.OverworldCode.GDgitHub2Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDproject2Objects1Objects = Hashtable.newFrom({"project2": gdjs.OverworldCode.GDproject2Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDchest3Objects1Objects = Hashtable.newFrom({"chest3": gdjs.OverworldCode.GDchest3Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDInfo2Objects1Objects = Hashtable.newFrom({"Info2": gdjs.OverworldCode.GDInfo2Objects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.OverworldCode.GDPlayerObjects1});
gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDHouse1Objects1Objects = Hashtable.newFrom({"House1": gdjs.OverworldCode.GDHouse1Objects1});
gdjs.OverworldCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.OverworldCode.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.OverworldCode.GDButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage"), gdjs.OverworldCode.GDCongratsMessageObjects1);
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage2"), gdjs.OverworldCode.GDCongratsMessage2Objects1);
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage3"), gdjs.OverworldCode.GDCongratsMessage3Objects1);
gdjs.copyArray(runtimeScene.getObjects("DialogBox"), gdjs.OverworldCode.GDDialogBoxObjects1);
gdjs.copyArray(runtimeScene.getObjects("E"), gdjs.OverworldCode.GDEObjects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.OverworldCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.OverworldCode.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("InfoBox_"), gdjs.OverworldCode.GDInfoBox_9595Objects1);
gdjs.copyArray(runtimeScene.getObjects("PopupBox1"), gdjs.OverworldCode.GDPopupBox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("PopupBox2"), gdjs.OverworldCode.GDPopupBox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PopupBox3"), gdjs.OverworldCode.GDPopupBox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("Quizz"), gdjs.OverworldCode.GDQuizzObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Ground"), gdjs.OverworldCode.GDTilemap_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Water"), gdjs.OverworldCode.GDTilemap_9595WaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.OverworldCode.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.OverworldCode.GDTree2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Welcome"), gdjs.OverworldCode.GDWelcomeObjects1);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.OverworldCode.GDbackButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("backButton2"), gdjs.OverworldCode.GDbackButton2Objects1);
gdjs.copyArray(runtimeScene.getObjects("backButton3"), gdjs.OverworldCode.GDbackButton3Objects1);
gdjs.copyArray(runtimeScene.getObjects("gitHub1"), gdjs.OverworldCode.GDgitHub1Objects1);
gdjs.copyArray(runtimeScene.getObjects("gitHub2"), gdjs.OverworldCode.GDgitHub2Objects1);
gdjs.copyArray(runtimeScene.getObjects("infoText"), gdjs.OverworldCode.GDinfoTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("project1"), gdjs.OverworldCode.GDproject1Objects1);
gdjs.copyArray(runtimeScene.getObjects("project2"), gdjs.OverworldCode.GDproject2Objects1);
{for(var i = 0, len = gdjs.OverworldCode.GDWelcomeObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDWelcomeObjects1[i].setCenterPositionInScene(700,250);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "", 0);
}{for(var i = 0, len = gdjs.OverworldCode.GDTree1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTree1Objects1[i].setZOrder((gdjs.OverworldCode.GDTree1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.OverworldCode.GDBush1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDBush1Objects1[i].setZOrder((gdjs.OverworldCode.GDBush1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.OverworldCode.GDTree2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTree2Objects1[i].setZOrder((gdjs.OverworldCode.GDTree2Objects1[i].getY()));
}
for(var i = 0, len = gdjs.OverworldCode.GDHouse1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDHouse1Objects1[i].setZOrder((gdjs.OverworldCode.GDHouse1Objects1[i].getY()));
}
for(var i = 0, len = gdjs.OverworldCode.GDHouse2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDHouse2Objects1[i].setZOrder((gdjs.OverworldCode.GDHouse2Objects1[i].getY()));
}
for(var i = 0, len = gdjs.OverworldCode.GDTilemap_9595GroundObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTilemap_9595GroundObjects1[i].setZOrder((gdjs.OverworldCode.GDTilemap_9595GroundObjects1[i].getY()));
}
for(var i = 0, len = gdjs.OverworldCode.GDTilemap_9595WaterObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDTilemap_9595WaterObjects1[i].setZOrder((gdjs.OverworldCode.GDTilemap_9595WaterObjects1[i].getY()));
}
}{for(var i = 0, len = gdjs.OverworldCode.GDEObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDEObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 0, 1, 10, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "ENCHANTED FOREST Azure-X Music2.mp3", true, 45, 1);
}{for(var i = 0, len = gdjs.OverworldCode.GDDialogBoxObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDDialogBoxObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessageObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessageObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDgitHub1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDgitHub1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDproject1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDproject1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessage2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessage2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButton2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButton2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDgitHub2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDgitHub2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDproject2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDproject2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessage3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessage3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButton3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButton3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDInfoBox_9595Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDInfoBox_9595Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDinfoTextObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDinfoTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDButtonObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDQuizzObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDQuizzObjects1[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Welcome"), gdjs.OverworldCode.GDWelcomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDWelcomeObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDWelcomeObjects1[i].IsYesClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDWelcomeObjects1[k] = gdjs.OverworldCode.GDWelcomeObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDWelcomeObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.OverworldCode.GDWelcomeObjects1 */
{for(var i = 0, len = gdjs.OverworldCode.GDWelcomeObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDWelcomeObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Welcome"), gdjs.OverworldCode.GDWelcomeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDWelcomeObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDWelcomeObjects1[i].IsNoClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDWelcomeObjects1[k] = gdjs.OverworldCode.GDWelcomeObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDWelcomeObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://www.linkedin.com/in/ralston-jnr-de-klerk-52b805317/", runtimeScene);
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bush1"), gdjs.OverworldCode.GDBush1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.OverworldCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("House2"), gdjs.OverworldCode.GDHouse2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Ground"), gdjs.OverworldCode.GDTilemap_9595GroundObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tilemap_Water"), gdjs.OverworldCode.GDTilemap_9595WaterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tree1"), gdjs.OverworldCode.GDTree1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Tree2"), gdjs.OverworldCode.GDTree2Objects1);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].separateFromObjectsList(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDTree1Objects1ObjectsGDgdjs_9546OverworldCode_9546GDBush1Objects1ObjectsGDgdjs_9546OverworldCode_9546GDTree2Objects1ObjectsGDgdjs_9546OverworldCode_9546GDHouse1Objects1ObjectsGDgdjs_9546OverworldCode_9546GDHouse2Objects1ObjectsGDgdjs_9546OverworldCode_9546GDTilemap_95959595GroundObjects1ObjectsGDgdjs_9546OverworldCode_9546GDTilemap_95959595WaterObjects1Objects, false);
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.OverworldCode.GDPlayerObjects1.length !== 0 ? gdjs.OverworldCode.GDPlayerObjects1[0] : null), true, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.OverworldCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDPlayerObjects1[k] = gdjs.OverworldCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].setAnimationFrame(0);
}
}}

}


{


gdjs.OverworldCode.eventsList2(runtimeScene);
}


{


gdjs.OverworldCode.eventsList4(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("coin"), gdjs.OverworldCode.GDcoinObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDcoinObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CoinTally"), gdjs.OverworldCode.GDCoinTallyObjects1);
/* Reuse gdjs.OverworldCode.GDcoinObjects1 */
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}{for(var i = 0, len = gdjs.OverworldCode.GDcoinObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDcoinObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCoinTallyObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCoinTallyObjects1[i].setBBText("Coins: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber()));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Retro Game Coin Sound Effect - Free Effects For Clips and Ambient Music and Sound.mp3", false, 80, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.OverworldCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDPlayerObjects1[k] = gdjs.OverworldCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDPlayerObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("scroll"), gdjs.OverworldCode.GDscrollObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDscrollObjects1.length !== 0 ? gdjs.OverworldCode.GDscrollObjects1[0] : null), 20, 45);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("scroll"), gdjs.OverworldCode.GDscrollObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDscrollObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Info2"), gdjs.OverworldCode.GDInfo2Objects1);
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
{gdjs.evtTools.window.openURL("https://ralstonjnr-portfolio.netlify.app/", runtimeScene);
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDInfo2Objects1.length !== 0 ? gdjs.OverworldCode.GDInfo2Objects1[0] : null), 25, 180);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("chest1"), gdjs.OverworldCode.GDchest1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDchest1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ChestTally"), gdjs.OverworldCode.GDChestTallyObjects1);
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage"), gdjs.OverworldCode.GDCongratsMessageObjects1);
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PopupBox1"), gdjs.OverworldCode.GDPopupBox1Objects1);
gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.OverworldCode.GDbackButtonObjects1);
/* Reuse gdjs.OverworldCode.GDchest1Objects1 */
gdjs.copyArray(runtimeScene.getObjects("gitHub1"), gdjs.OverworldCode.GDgitHub1Objects1);
gdjs.copyArray(runtimeScene.getObjects("project1"), gdjs.OverworldCode.GDproject1Objects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Chest Opening (Minecraft Sound) - Sound Effect for editing - Sound Library.mp3", false, 85, 1);
}{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox1Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessageObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessageObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDproject1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDproject1Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDgitHub1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDgitHub1Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDchest1Objects1.length !== 0 ? gdjs.OverworldCode.GDchest1Objects1[0] : null), 15, 50);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDChestTallyObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDChestTallyObjects1[i].setBBText("Treasure Chest: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gitHub1"), gdjs.OverworldCode.GDgitHub1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDgitHub1Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{gdjs.evtTools.window.openURL("https://github.com/RalstonJnr/adventure", runtimeScene);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("project1"), gdjs.OverworldCode.GDproject1Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDproject1Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}{gdjs.evtTools.window.openURL("https://her-menu-invitation.netlify.app/", runtimeScene);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton"), gdjs.OverworldCode.GDbackButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDbackButtonObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDbackButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDbackButtonObjects1[k] = gdjs.OverworldCode.GDbackButtonObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDbackButtonObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage"), gdjs.OverworldCode.GDCongratsMessageObjects1);
gdjs.copyArray(runtimeScene.getObjects("PopupBox1"), gdjs.OverworldCode.GDPopupBox1Objects1);
/* Reuse gdjs.OverworldCode.GDbackButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("gitHub1"), gdjs.OverworldCode.GDgitHub1Objects1);
gdjs.copyArray(runtimeScene.getObjects("project1"), gdjs.OverworldCode.GDproject1Objects1);
{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessageObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessageObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButtonObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButtonObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDproject1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDproject1Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDgitHub1Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDgitHub1Objects1[i].hide();
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("chest2"), gdjs.OverworldCode.GDchest2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDchest2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ChestTally"), gdjs.OverworldCode.GDChestTallyObjects1);
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage2"), gdjs.OverworldCode.GDCongratsMessage2Objects1);
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PopupBox2"), gdjs.OverworldCode.GDPopupBox2Objects1);
gdjs.copyArray(runtimeScene.getObjects("backButton2"), gdjs.OverworldCode.GDbackButton2Objects1);
/* Reuse gdjs.OverworldCode.GDchest2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("gitHub2"), gdjs.OverworldCode.GDgitHub2Objects1);
gdjs.copyArray(runtimeScene.getObjects("project2"), gdjs.OverworldCode.GDproject2Objects1);
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Chest Opening (Minecraft Sound) - Sound Effect for editing - Sound Library.mp3", false, 85, 1);
}{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessage2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessage2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDproject2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDproject2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDgitHub2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDgitHub2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButton2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButton2Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDchest2Objects1.length !== 0 ? gdjs.OverworldCode.GDchest2Objects1[0] : null), 20, 90);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDChestTallyObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDChestTallyObjects1[i].setBBText("Treasure Chest: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("gitHub2"), gdjs.OverworldCode.GDgitHub2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDgitHub2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://github.com/RalstonJnr/easiorders", runtimeScene);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("project2"), gdjs.OverworldCode.GDproject2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDproject2Objects1Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getScene().getVariables().getFromIndex(1).getAsBoolean();
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.window.openURL("https://easiorders.onrender.com", runtimeScene);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setBoolean(true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton2"), gdjs.OverworldCode.GDbackButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDbackButton2Objects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDbackButton2Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDbackButton2Objects1[k] = gdjs.OverworldCode.GDbackButton2Objects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDbackButton2Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage2"), gdjs.OverworldCode.GDCongratsMessage2Objects1);
gdjs.copyArray(runtimeScene.getObjects("PopupBox2"), gdjs.OverworldCode.GDPopupBox2Objects1);
/* Reuse gdjs.OverworldCode.GDbackButton2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("gitHub2"), gdjs.OverworldCode.GDgitHub2Objects1);
gdjs.copyArray(runtimeScene.getObjects("project2"), gdjs.OverworldCode.GDproject2Objects1);
{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessage2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessage2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButton2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButton2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDproject2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDproject2Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDgitHub2Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDgitHub2Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("chest3"), gdjs.OverworldCode.GDchest3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDchest3Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("ChestTally"), gdjs.OverworldCode.GDChestTallyObjects1);
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage3"), gdjs.OverworldCode.GDCongratsMessage3Objects1);
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("PopupBox3"), gdjs.OverworldCode.GDPopupBox3Objects1);
gdjs.copyArray(runtimeScene.getObjects("backButton3"), gdjs.OverworldCode.GDbackButton3Objects1);
/* Reuse gdjs.OverworldCode.GDchest3Objects1 */
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Chest Opening (Minecraft Sound) - Sound Effect for editing - Sound Library.mp3", false, 75, 1);
}{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessage3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessage3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButton3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButton3Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDchest3Objects1.length !== 0 ? gdjs.OverworldCode.GDchest3Objects1[0] : null), 15, 180);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDChestTallyObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDChestTallyObjects1[i].setBBText("Treasure Chest: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("backButton3"), gdjs.OverworldCode.GDbackButton3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDbackButton3Objects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDbackButton3Objects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDbackButton3Objects1[k] = gdjs.OverworldCode.GDbackButton3Objects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDbackButton3Objects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("CongratsMessage3"), gdjs.OverworldCode.GDCongratsMessage3Objects1);
gdjs.copyArray(runtimeScene.getObjects("PopupBox3"), gdjs.OverworldCode.GDPopupBox3Objects1);
/* Reuse gdjs.OverworldCode.GDbackButton3Objects1 */
{for(var i = 0, len = gdjs.OverworldCode.GDPopupBox3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPopupBox3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDCongratsMessage3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDCongratsMessage3Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDbackButton3Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDbackButton3Objects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Info2"), gdjs.OverworldCode.GDInfo2Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDInfo2Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.OverworldCode.GDButtonObjects1);
/* Reuse gdjs.OverworldCode.GDInfo2Objects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoBox_"), gdjs.OverworldCode.GDInfoBox_9595Objects1);
/* Reuse gdjs.OverworldCode.GDPlayerObjects1 */
gdjs.copyArray(runtimeScene.getObjects("infoText"), gdjs.OverworldCode.GDinfoTextObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDInfoBox_9595Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDInfoBox_9595Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDinfoTextObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDinfoTextObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDButtonObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDButtonObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDInfo2Objects1.length !== 0 ? gdjs.OverworldCode.GDInfo2Objects1[0] : null), 40, 180);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Button"), gdjs.OverworldCode.GDButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDButtonObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDButtonObjects1[k] = gdjs.OverworldCode.GDButtonObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDButtonObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.OverworldCode.GDButtonObjects1 */
gdjs.copyArray(runtimeScene.getObjects("InfoBox_"), gdjs.OverworldCode.GDInfoBox_9595Objects1);
gdjs.copyArray(runtimeScene.getObjects("infoText"), gdjs.OverworldCode.GDinfoTextObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDinfoTextObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDinfoTextObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDInfoBox_9595Objects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDInfoBox_9595Objects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDButtonObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDButtonObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.OverworldCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDPlayerObjects1Objects, gdjs.OverworldCode.mapOfGDgdjs_9546OverworldCode_9546GDHouse1Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Quizz"), gdjs.OverworldCode.GDQuizzObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDQuizzObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDQuizzObjects1[i].setCenterPositionInScene(700,250);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDQuizzObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDQuizzObjects1[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quizz"), gdjs.OverworldCode.GDQuizzObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDQuizzObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDQuizzObjects1[i].IsYesClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDQuizzObjects1[k] = gdjs.OverworldCode.GDQuizzObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDQuizzObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
/* Reuse gdjs.OverworldCode.GDQuizzObjects1 */
gdjs.copyArray(runtimeScene.getObjects("scroll"), gdjs.OverworldCode.GDscrollObjects1);
{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDscrollObjects1.length !== 0 ? gdjs.OverworldCode.GDscrollObjects1[0] : null), 20, 45);
}
}{for(var i = 0, len = gdjs.OverworldCode.GDQuizzObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDQuizzObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Quizz"), gdjs.OverworldCode.GDQuizzObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.OverworldCode.GDQuizzObjects1.length;i<l;++i) {
    if ( gdjs.OverworldCode.GDQuizzObjects1[i].IsNoClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.OverworldCode.GDQuizzObjects1[k] = gdjs.OverworldCode.GDQuizzObjects1[i];
        ++k;
    }
}
gdjs.OverworldCode.GDQuizzObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("House1"), gdjs.OverworldCode.GDHouse1Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.OverworldCode.GDPlayerObjects1);
/* Reuse gdjs.OverworldCode.GDQuizzObjects1 */
{for(var i = 0, len = gdjs.OverworldCode.GDQuizzObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDQuizzObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.OverworldCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.OverworldCode.GDPlayerObjects1[i].putAroundObject((gdjs.OverworldCode.GDHouse1Objects1.length !== 0 ? gdjs.OverworldCode.GDHouse1Objects1[0] : null), 25, 90);
}
}}

}


};

gdjs.OverworldCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.OverworldCode.GDDialogBoxObjects1.length = 0;
gdjs.OverworldCode.GDDialogBoxObjects2.length = 0;
gdjs.OverworldCode.GDDialogBoxObjects3.length = 0;
gdjs.OverworldCode.GDDialogBoxObjects4.length = 0;
gdjs.OverworldCode.GDPlayerObjects1.length = 0;
gdjs.OverworldCode.GDPlayerObjects2.length = 0;
gdjs.OverworldCode.GDPlayerObjects3.length = 0;
gdjs.OverworldCode.GDPlayerObjects4.length = 0;
gdjs.OverworldCode.GDTree1Objects1.length = 0;
gdjs.OverworldCode.GDTree1Objects2.length = 0;
gdjs.OverworldCode.GDTree1Objects3.length = 0;
gdjs.OverworldCode.GDTree1Objects4.length = 0;
gdjs.OverworldCode.GDTree2Objects1.length = 0;
gdjs.OverworldCode.GDTree2Objects2.length = 0;
gdjs.OverworldCode.GDTree2Objects3.length = 0;
gdjs.OverworldCode.GDTree2Objects4.length = 0;
gdjs.OverworldCode.GDBush1Objects1.length = 0;
gdjs.OverworldCode.GDBush1Objects2.length = 0;
gdjs.OverworldCode.GDBush1Objects3.length = 0;
gdjs.OverworldCode.GDBush1Objects4.length = 0;
gdjs.OverworldCode.GDHouse1Objects1.length = 0;
gdjs.OverworldCode.GDHouse1Objects2.length = 0;
gdjs.OverworldCode.GDHouse1Objects3.length = 0;
gdjs.OverworldCode.GDHouse1Objects4.length = 0;
gdjs.OverworldCode.GDHouse2Objects1.length = 0;
gdjs.OverworldCode.GDHouse2Objects2.length = 0;
gdjs.OverworldCode.GDHouse2Objects3.length = 0;
gdjs.OverworldCode.GDHouse2Objects4.length = 0;
gdjs.OverworldCode.GDEObjects1.length = 0;
gdjs.OverworldCode.GDEObjects2.length = 0;
gdjs.OverworldCode.GDEObjects3.length = 0;
gdjs.OverworldCode.GDEObjects4.length = 0;
gdjs.OverworldCode.GDE2Objects1.length = 0;
gdjs.OverworldCode.GDE2Objects2.length = 0;
gdjs.OverworldCode.GDE2Objects3.length = 0;
gdjs.OverworldCode.GDE2Objects4.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects4.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects1.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects2.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects3.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects4.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects1.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects2.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects3.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects4.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects1.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects2.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects3.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects4.length = 0;
gdjs.OverworldCode.GDcoinObjects1.length = 0;
gdjs.OverworldCode.GDcoinObjects2.length = 0;
gdjs.OverworldCode.GDcoinObjects3.length = 0;
gdjs.OverworldCode.GDcoinObjects4.length = 0;
gdjs.OverworldCode.GDscrollObjects1.length = 0;
gdjs.OverworldCode.GDscrollObjects2.length = 0;
gdjs.OverworldCode.GDscrollObjects3.length = 0;
gdjs.OverworldCode.GDscrollObjects4.length = 0;
gdjs.OverworldCode.GDchest1Objects1.length = 0;
gdjs.OverworldCode.GDchest1Objects2.length = 0;
gdjs.OverworldCode.GDchest1Objects3.length = 0;
gdjs.OverworldCode.GDchest1Objects4.length = 0;
gdjs.OverworldCode.GDchest2Objects1.length = 0;
gdjs.OverworldCode.GDchest2Objects2.length = 0;
gdjs.OverworldCode.GDchest2Objects3.length = 0;
gdjs.OverworldCode.GDchest2Objects4.length = 0;
gdjs.OverworldCode.GDchest3Objects1.length = 0;
gdjs.OverworldCode.GDchest3Objects2.length = 0;
gdjs.OverworldCode.GDchest3Objects3.length = 0;
gdjs.OverworldCode.GDchest3Objects4.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects1.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects2.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects3.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects4.length = 0;
gdjs.OverworldCode.GDWelcomeObjects1.length = 0;
gdjs.OverworldCode.GDWelcomeObjects2.length = 0;
gdjs.OverworldCode.GDWelcomeObjects3.length = 0;
gdjs.OverworldCode.GDWelcomeObjects4.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects1.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects2.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects3.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects4.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects1.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects2.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects3.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects4.length = 0;
gdjs.OverworldCode.GDbackButtonObjects1.length = 0;
gdjs.OverworldCode.GDbackButtonObjects2.length = 0;
gdjs.OverworldCode.GDbackButtonObjects3.length = 0;
gdjs.OverworldCode.GDbackButtonObjects4.length = 0;
gdjs.OverworldCode.GDgitHub1Objects1.length = 0;
gdjs.OverworldCode.GDgitHub1Objects2.length = 0;
gdjs.OverworldCode.GDgitHub1Objects3.length = 0;
gdjs.OverworldCode.GDgitHub1Objects4.length = 0;
gdjs.OverworldCode.GDproject1Objects1.length = 0;
gdjs.OverworldCode.GDproject1Objects2.length = 0;
gdjs.OverworldCode.GDproject1Objects3.length = 0;
gdjs.OverworldCode.GDproject1Objects4.length = 0;
gdjs.OverworldCode.GDChestTallyObjects1.length = 0;
gdjs.OverworldCode.GDChestTallyObjects2.length = 0;
gdjs.OverworldCode.GDChestTallyObjects3.length = 0;
gdjs.OverworldCode.GDChestTallyObjects4.length = 0;
gdjs.OverworldCode.GDBoatObjects1.length = 0;
gdjs.OverworldCode.GDBoatObjects2.length = 0;
gdjs.OverworldCode.GDBoatObjects3.length = 0;
gdjs.OverworldCode.GDBoatObjects4.length = 0;
gdjs.OverworldCode.GDTurtleObjects1.length = 0;
gdjs.OverworldCode.GDTurtleObjects2.length = 0;
gdjs.OverworldCode.GDTurtleObjects3.length = 0;
gdjs.OverworldCode.GDTurtleObjects4.length = 0;
gdjs.OverworldCode.GDproject2Objects1.length = 0;
gdjs.OverworldCode.GDproject2Objects2.length = 0;
gdjs.OverworldCode.GDproject2Objects3.length = 0;
gdjs.OverworldCode.GDproject2Objects4.length = 0;
gdjs.OverworldCode.GDgitHub2Objects1.length = 0;
gdjs.OverworldCode.GDgitHub2Objects2.length = 0;
gdjs.OverworldCode.GDgitHub2Objects3.length = 0;
gdjs.OverworldCode.GDgitHub2Objects4.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects1.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects2.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects3.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects4.length = 0;
gdjs.OverworldCode.GDbackButton2Objects1.length = 0;
gdjs.OverworldCode.GDbackButton2Objects2.length = 0;
gdjs.OverworldCode.GDbackButton2Objects3.length = 0;
gdjs.OverworldCode.GDbackButton2Objects4.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects1.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects2.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects3.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects4.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects1.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects2.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects3.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects4.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects1.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects2.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects3.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects4.length = 0;
gdjs.OverworldCode.GDbackButton3Objects1.length = 0;
gdjs.OverworldCode.GDbackButton3Objects2.length = 0;
gdjs.OverworldCode.GDbackButton3Objects3.length = 0;
gdjs.OverworldCode.GDbackButton3Objects4.length = 0;
gdjs.OverworldCode.GDInfo2Objects1.length = 0;
gdjs.OverworldCode.GDInfo2Objects2.length = 0;
gdjs.OverworldCode.GDInfo2Objects3.length = 0;
gdjs.OverworldCode.GDInfo2Objects4.length = 0;
gdjs.OverworldCode.GDinfoTextObjects1.length = 0;
gdjs.OverworldCode.GDinfoTextObjects2.length = 0;
gdjs.OverworldCode.GDinfoTextObjects3.length = 0;
gdjs.OverworldCode.GDinfoTextObjects4.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects1.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects2.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects3.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects4.length = 0;
gdjs.OverworldCode.GDButtonObjects1.length = 0;
gdjs.OverworldCode.GDButtonObjects2.length = 0;
gdjs.OverworldCode.GDButtonObjects3.length = 0;
gdjs.OverworldCode.GDButtonObjects4.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects1.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects2.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects3.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects4.length = 0;
gdjs.OverworldCode.GDQuizzObjects1.length = 0;
gdjs.OverworldCode.GDQuizzObjects2.length = 0;
gdjs.OverworldCode.GDQuizzObjects3.length = 0;
gdjs.OverworldCode.GDQuizzObjects4.length = 0;
gdjs.OverworldCode.GDTransitionObjects1.length = 0;
gdjs.OverworldCode.GDTransitionObjects2.length = 0;
gdjs.OverworldCode.GDTransitionObjects3.length = 0;
gdjs.OverworldCode.GDTransitionObjects4.length = 0;

gdjs.OverworldCode.eventsList5(runtimeScene);
gdjs.OverworldCode.GDDialogBoxObjects1.length = 0;
gdjs.OverworldCode.GDDialogBoxObjects2.length = 0;
gdjs.OverworldCode.GDDialogBoxObjects3.length = 0;
gdjs.OverworldCode.GDDialogBoxObjects4.length = 0;
gdjs.OverworldCode.GDPlayerObjects1.length = 0;
gdjs.OverworldCode.GDPlayerObjects2.length = 0;
gdjs.OverworldCode.GDPlayerObjects3.length = 0;
gdjs.OverworldCode.GDPlayerObjects4.length = 0;
gdjs.OverworldCode.GDTree1Objects1.length = 0;
gdjs.OverworldCode.GDTree1Objects2.length = 0;
gdjs.OverworldCode.GDTree1Objects3.length = 0;
gdjs.OverworldCode.GDTree1Objects4.length = 0;
gdjs.OverworldCode.GDTree2Objects1.length = 0;
gdjs.OverworldCode.GDTree2Objects2.length = 0;
gdjs.OverworldCode.GDTree2Objects3.length = 0;
gdjs.OverworldCode.GDTree2Objects4.length = 0;
gdjs.OverworldCode.GDBush1Objects1.length = 0;
gdjs.OverworldCode.GDBush1Objects2.length = 0;
gdjs.OverworldCode.GDBush1Objects3.length = 0;
gdjs.OverworldCode.GDBush1Objects4.length = 0;
gdjs.OverworldCode.GDHouse1Objects1.length = 0;
gdjs.OverworldCode.GDHouse1Objects2.length = 0;
gdjs.OverworldCode.GDHouse1Objects3.length = 0;
gdjs.OverworldCode.GDHouse1Objects4.length = 0;
gdjs.OverworldCode.GDHouse2Objects1.length = 0;
gdjs.OverworldCode.GDHouse2Objects2.length = 0;
gdjs.OverworldCode.GDHouse2Objects3.length = 0;
gdjs.OverworldCode.GDHouse2Objects4.length = 0;
gdjs.OverworldCode.GDEObjects1.length = 0;
gdjs.OverworldCode.GDEObjects2.length = 0;
gdjs.OverworldCode.GDEObjects3.length = 0;
gdjs.OverworldCode.GDEObjects4.length = 0;
gdjs.OverworldCode.GDE2Objects1.length = 0;
gdjs.OverworldCode.GDE2Objects2.length = 0;
gdjs.OverworldCode.GDE2Objects3.length = 0;
gdjs.OverworldCode.GDE2Objects4.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects1.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects2.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects3.length = 0;
gdjs.OverworldCode.GDShadedDarkJoystickObjects4.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects1.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects2.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects3.length = 0;
gdjs.OverworldCode.GDTargetRoundButtonObjects4.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects1.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects2.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects3.length = 0;
gdjs.OverworldCode.GDTilemap_9595GroundObjects4.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects1.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects2.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects3.length = 0;
gdjs.OverworldCode.GDTilemap_9595WaterObjects4.length = 0;
gdjs.OverworldCode.GDcoinObjects1.length = 0;
gdjs.OverworldCode.GDcoinObjects2.length = 0;
gdjs.OverworldCode.GDcoinObjects3.length = 0;
gdjs.OverworldCode.GDcoinObjects4.length = 0;
gdjs.OverworldCode.GDscrollObjects1.length = 0;
gdjs.OverworldCode.GDscrollObjects2.length = 0;
gdjs.OverworldCode.GDscrollObjects3.length = 0;
gdjs.OverworldCode.GDscrollObjects4.length = 0;
gdjs.OverworldCode.GDchest1Objects1.length = 0;
gdjs.OverworldCode.GDchest1Objects2.length = 0;
gdjs.OverworldCode.GDchest1Objects3.length = 0;
gdjs.OverworldCode.GDchest1Objects4.length = 0;
gdjs.OverworldCode.GDchest2Objects1.length = 0;
gdjs.OverworldCode.GDchest2Objects2.length = 0;
gdjs.OverworldCode.GDchest2Objects3.length = 0;
gdjs.OverworldCode.GDchest2Objects4.length = 0;
gdjs.OverworldCode.GDchest3Objects1.length = 0;
gdjs.OverworldCode.GDchest3Objects2.length = 0;
gdjs.OverworldCode.GDchest3Objects3.length = 0;
gdjs.OverworldCode.GDchest3Objects4.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects1.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects2.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects3.length = 0;
gdjs.OverworldCode.GDCoinTallyObjects4.length = 0;
gdjs.OverworldCode.GDWelcomeObjects1.length = 0;
gdjs.OverworldCode.GDWelcomeObjects2.length = 0;
gdjs.OverworldCode.GDWelcomeObjects3.length = 0;
gdjs.OverworldCode.GDWelcomeObjects4.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects1.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects2.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects3.length = 0;
gdjs.OverworldCode.GDPopupBox1Objects4.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects1.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects2.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects3.length = 0;
gdjs.OverworldCode.GDCongratsMessageObjects4.length = 0;
gdjs.OverworldCode.GDbackButtonObjects1.length = 0;
gdjs.OverworldCode.GDbackButtonObjects2.length = 0;
gdjs.OverworldCode.GDbackButtonObjects3.length = 0;
gdjs.OverworldCode.GDbackButtonObjects4.length = 0;
gdjs.OverworldCode.GDgitHub1Objects1.length = 0;
gdjs.OverworldCode.GDgitHub1Objects2.length = 0;
gdjs.OverworldCode.GDgitHub1Objects3.length = 0;
gdjs.OverworldCode.GDgitHub1Objects4.length = 0;
gdjs.OverworldCode.GDproject1Objects1.length = 0;
gdjs.OverworldCode.GDproject1Objects2.length = 0;
gdjs.OverworldCode.GDproject1Objects3.length = 0;
gdjs.OverworldCode.GDproject1Objects4.length = 0;
gdjs.OverworldCode.GDChestTallyObjects1.length = 0;
gdjs.OverworldCode.GDChestTallyObjects2.length = 0;
gdjs.OverworldCode.GDChestTallyObjects3.length = 0;
gdjs.OverworldCode.GDChestTallyObjects4.length = 0;
gdjs.OverworldCode.GDBoatObjects1.length = 0;
gdjs.OverworldCode.GDBoatObjects2.length = 0;
gdjs.OverworldCode.GDBoatObjects3.length = 0;
gdjs.OverworldCode.GDBoatObjects4.length = 0;
gdjs.OverworldCode.GDTurtleObjects1.length = 0;
gdjs.OverworldCode.GDTurtleObjects2.length = 0;
gdjs.OverworldCode.GDTurtleObjects3.length = 0;
gdjs.OverworldCode.GDTurtleObjects4.length = 0;
gdjs.OverworldCode.GDproject2Objects1.length = 0;
gdjs.OverworldCode.GDproject2Objects2.length = 0;
gdjs.OverworldCode.GDproject2Objects3.length = 0;
gdjs.OverworldCode.GDproject2Objects4.length = 0;
gdjs.OverworldCode.GDgitHub2Objects1.length = 0;
gdjs.OverworldCode.GDgitHub2Objects2.length = 0;
gdjs.OverworldCode.GDgitHub2Objects3.length = 0;
gdjs.OverworldCode.GDgitHub2Objects4.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects1.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects2.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects3.length = 0;
gdjs.OverworldCode.GDPopupBox2Objects4.length = 0;
gdjs.OverworldCode.GDbackButton2Objects1.length = 0;
gdjs.OverworldCode.GDbackButton2Objects2.length = 0;
gdjs.OverworldCode.GDbackButton2Objects3.length = 0;
gdjs.OverworldCode.GDbackButton2Objects4.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects1.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects2.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects3.length = 0;
gdjs.OverworldCode.GDCongratsMessage2Objects4.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects1.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects2.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects3.length = 0;
gdjs.OverworldCode.GDCongratsMessage3Objects4.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects1.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects2.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects3.length = 0;
gdjs.OverworldCode.GDPopupBox3Objects4.length = 0;
gdjs.OverworldCode.GDbackButton3Objects1.length = 0;
gdjs.OverworldCode.GDbackButton3Objects2.length = 0;
gdjs.OverworldCode.GDbackButton3Objects3.length = 0;
gdjs.OverworldCode.GDbackButton3Objects4.length = 0;
gdjs.OverworldCode.GDInfo2Objects1.length = 0;
gdjs.OverworldCode.GDInfo2Objects2.length = 0;
gdjs.OverworldCode.GDInfo2Objects3.length = 0;
gdjs.OverworldCode.GDInfo2Objects4.length = 0;
gdjs.OverworldCode.GDinfoTextObjects1.length = 0;
gdjs.OverworldCode.GDinfoTextObjects2.length = 0;
gdjs.OverworldCode.GDinfoTextObjects3.length = 0;
gdjs.OverworldCode.GDinfoTextObjects4.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects1.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects2.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects3.length = 0;
gdjs.OverworldCode.GDInfoBox_9595Objects4.length = 0;
gdjs.OverworldCode.GDButtonObjects1.length = 0;
gdjs.OverworldCode.GDButtonObjects2.length = 0;
gdjs.OverworldCode.GDButtonObjects3.length = 0;
gdjs.OverworldCode.GDButtonObjects4.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects1.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects2.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects3.length = 0;
gdjs.OverworldCode.GDNewTextInputObjects4.length = 0;
gdjs.OverworldCode.GDQuizzObjects1.length = 0;
gdjs.OverworldCode.GDQuizzObjects2.length = 0;
gdjs.OverworldCode.GDQuizzObjects3.length = 0;
gdjs.OverworldCode.GDQuizzObjects4.length = 0;
gdjs.OverworldCode.GDTransitionObjects1.length = 0;
gdjs.OverworldCode.GDTransitionObjects2.length = 0;
gdjs.OverworldCode.GDTransitionObjects3.length = 0;
gdjs.OverworldCode.GDTransitionObjects4.length = 0;


return;

}

gdjs['OverworldCode'] = gdjs.OverworldCode;
